package day2;

public class Ex201 {
    public static void main(String[] args) {
        int num =5;
        double num2=num;
        System.out.println(num2);

        double num3=3;
        //int num4= num3;

        
    }
}
