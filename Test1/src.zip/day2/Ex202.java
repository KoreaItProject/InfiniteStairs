package day2;

public class Ex202 {
    public static void main(String[] args) {
        byte b=2;
        short s= b;
        int i= s;
        long l=i;
        float f=l;
        double d= f;
        System.out.println(d);


    }
}
