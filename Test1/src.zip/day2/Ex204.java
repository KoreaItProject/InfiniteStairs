package day2;

public class Ex204 {
    public static void main(String[] args) {
        int num;
        num=2-3;
        
        num+=3;
        num-=1;
        num*=7;
        num/=3;
        num%=5;
        
        System.out.println(num);
    }
}
