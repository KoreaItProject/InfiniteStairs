package day1;

public class Ex101 {

	public static void main(String[] args) {
		//main 메서드
		int num;
		num=5;

		System.out.println("num : "+num);

		int a; 
		a= 10;
		System.out.println("a : " + a);


		double b;
		b=3.14;
		System.out.println("b : " + b);


		

	}

}
