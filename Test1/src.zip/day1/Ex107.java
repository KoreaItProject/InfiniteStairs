package day1;
public class Ex107 {
    public static void main(String[] args) {
        int i = 10;
        //byte j = i;
        //4바이트 안에 1바이트를 넣을 수 없음!

        byte k = 10;
        int n=k;
        System.out.println(n);

    }
}
