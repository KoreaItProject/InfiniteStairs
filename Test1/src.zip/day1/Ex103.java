package day1;
public class Ex103 {
    public static void main(String[] args) {
       int num=5;
       int num1=num;
       num++;
       System.out.println("num : "+num);
       System.out.println("num1 : "+num1);

    }
}
