package swing;
import javax.swing.*;
import java.awt.*;
import java.sql.Time;
import java.awt.event.KeyAdapter;import java.awt.event.KeyEvent;
public class test1 extends JFrame{

     int FramW=1400,FramH=900
     ,blockW=100,blockH=50,blockX=650,blockY=500,
     charW=200,charH=200,charX=600,charY=310
     ,startBackH=-4130;

     int moveX=-110,moveY=50;
     Image imgch;
     int keyCount=0;

 
    public test1()
    {
       
        super("J프레임 테스트");  //프레임의 타이틀
        setSize(FramW,FramH);        //컨테이너 크기 지정
        setDefaultCloseOperation(EXIT_ON_CLOSE);

       
        setResizable(false);
        setLocationRelativeTo(null);

        ImageIcon background = new ImageIcon("Test1\\src\\img\\backg.png");
        imgch =background.getImage().getScaledInstance(FramW, 5000, Image.SCALE_SMOOTH);
        ImageIcon backgroundIcon =new ImageIcon(imgch);

        //레이블을 넣기 위한 패널 생성


        JPanel backPanel = new JPanel(){ };

        
        //패널 레이아웃 설정    레이아웃을 설정해야지 버튼의 위치 크기를 조절할 수 있다.(기본 레이아웃은 불가)
        backPanel.setLayout(null);
        
        //버튼 생성
        //JButton btn = new JButton("b1");
        ///////캐릭터 이미지 생성//////////
           ImageIcon  char1img = new ImageIcon ("Test1\\src\\img\\char1.png");
           imgch =char1img.getImage().getScaledInstance(charW, charH, Image.SCALE_SMOOTH);
           ImageIcon char1Icon =new ImageIcon(imgch);
   
           ImageIcon  char2img = new ImageIcon ("Test1\\src\\img\\char2.png");
           imgch =char2img.getImage().getScaledInstance(charW, charH, Image.SCALE_SMOOTH);
           ImageIcon char2Icon =new ImageIcon(imgch);

           ImageIcon  char3img = new ImageIcon ("Test1\\src\\img\\char3.png");
           imgch =char3img.getImage().getScaledInstance(charW, charH, Image.SCALE_SMOOTH);
           ImageIcon char3Icon =new ImageIcon(imgch);

           ImageIcon  char4img = new ImageIcon ("Test1\\src\\img\\char4.png");
           imgch =char4img.getImage().getScaledInstance(charW, charH, Image.SCALE_SMOOTH);
           ImageIcon char4Icon =new ImageIcon(imgch);

        //이미지 레이블 생성
     

        ImageIcon  block = new ImageIcon ("Test1\\src\\img\\block.png");
        imgch =block.getImage().getScaledInstance(blockW, blockH, Image.SCALE_SMOOTH);
        ImageIcon blockIcon =new ImageIcon(imgch);

      


        JLabel backlbl=new JLabel(backgroundIcon);
        JLabel charlbl = new JLabel(char3Icon);
        JLabel [] blockArr=new JLabel[200];
        int result[]=new int[200];

       //패널에 모두 추가
        backPanel.add(charlbl);
     
        for(int i=0;i<blockArr.length;i++){

            blockArr[i]=(new JLabel(blockIcon));
            backPanel.add(blockArr[i]);
            blockArr[i].setBounds(blockX,blockY,blockW,blockH);
            int n=0;
            if(i!=0){
                n= (int)(Math.random()*2);
            }
           if(n==0){
                blockX-=110;
                
           }else{
                blockX+=110;
                
           }
                result[i]=n;
                blockY-=50;

        }
        backPanel.setSize(FramW, FramH);
        backPanel.add(backlbl);
      
      

        

       
        charlbl.setBounds(charX,charY,charW,charW);
        backlbl.setBounds(0,startBackH,FramW,5000);
        //컨테이너에 패널 추가
        add(backPanel);

      
            addKeyListener(new KeyAdapter(){public void keyPressed(KeyEvent e){
                switch(e.getKeyCode()){
                    
                    case KeyEvent.VK_LEFT:
                        backlbl.setLocation(0,backlbl.getLocation().y+10);
                        moveX*=-1;
                        if(moveX>0){
                            charlbl.setIcon(char1Icon);
                             
                        }else{
                            charlbl.setIcon(char3Icon);               
                        }
                        for(int i=0; i<blockArr.length;i++){
                            blockArr[i].setLocation(blockArr[i].getLocation().x-moveX,blockArr[i].getLocation().y+moveY);
                        }
                        if(result[keyCount]==0&&moveX>0||result[keyCount]==1&&moveX<0){
                            System.out.println("게임오버");
                            new test1();
                            dispose();
                        }
                            

                    break;

                    case KeyEvent.VK_RIGHT:

                        backlbl.setLocation(0,backlbl.getLocation().y+3);
                        
                        for(int i=0; i<blockArr.length;i++){
                            blockArr[i].setLocation(blockArr[i].getLocation().x-moveX,blockArr[i].getLocation().y+moveY);
                        }
                        if(result[keyCount]==1&&moveX<0||result[keyCount]==0&&moveX>0){
                            System.out.println("게임오버");
                            new test1();
                            dispose();
                            
                        }
                            
                    break;
                } 
                keyCount++;
            }
            });
        
        setVisible(true);  
              //창을 보이게함
      
       


    }
    
    public static void main(String[] args) {
 
        test1  t = new test1();
 
    }
}
