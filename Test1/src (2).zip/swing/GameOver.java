package swing;

import javax.swing.JFrame;

public class GameOver extends JFrame{
    GameOver(){
        setVisible(true);  
    }
}
