package day1;
public class Ex104 {
    public static void main(String[] args) {
        
    }
}
