package day1;
public class Ex105 {
    public static void main(String[] args) {
        byte b;
        b=-128;
        b--;
        System.out.println(b);


        int num;
        num=-2____1_00_0______0___1_110;
        System.out.println(num);




        
    }
}
