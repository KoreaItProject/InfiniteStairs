package day1;
public class Ex102 {
    public static void main(String[] args) {

        //byte 1 short 2 int 4 long 8 float 4 double 8
        //byte -128 ~ +127
        //int -21억 ~ +21억

        int n = 5;    
        double n2=5.15;
        char n3='a';
        String n4="str"+"ing";
        boolean n5=true;
        float n6=1;


        System.out.println("n : " + n);
        System.out.println("n2 : " + n2);
        System.out.println("n3 : " + n3);
        System.out.println("n4 : " + n4);
        System.out.println("n5 : " + n5);
        System.out.println("n6 : "+n6);

        int num1 = 5+7;
        System.out.println("num1 : "+num1);

        double num2 =5.15+5;
        System.out.println("num2 : "+num2);



    }
}
