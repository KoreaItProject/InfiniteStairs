package day1;

public class Ex100 {

	public static void main(String[] args) {
		
		/* System.out.println("Hello world"); */
		System.out.println(123);//정수
		System.out.println(3.14);//실수
		
		String s1; //문자열 변수 s1선언
		s1="hello";
		String s2="world";
		System.out.println(s1 + " " +s2);
		
		String name="lee tae hyeon";
		System.out.println("I'm "+name + "!");
				
				

		System.out.println((int)(Math.random()*499+2000));
		
	}

}
