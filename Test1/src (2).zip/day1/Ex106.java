package day1;
public class Ex106 {
    public static void main(String[] args) {
        int a =5;
        a=10;
        a=15;

        final int B=5;
        final double PI=3.131592;


    }
}
