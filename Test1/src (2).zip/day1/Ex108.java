package day1;
public class Ex108 {
    public static void main(String[] args) {
        //1
        int a=33;
        //2
        double b=3.14;
        //3
        char c='가';
        //4
        System.out.println("a : "+a+"\nb : "+b+"\nc : "+c);
        int x=5,y=3;
        System.out.println(x+y);
        //5
        int x2=5,y2=3;
        int z=x2+y2;
        System.out.println(z);
        //6
        final double PI=3.14;
        int r=10;
        double area=PI*r*r;
        System.out.println(area);


    }
}
