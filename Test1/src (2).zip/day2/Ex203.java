package day2;

public class Ex203 {
    public static void main(String[] args) {
        int a=10;
        int b=3;
        System.out.println(a+b);
        System.out.println(a-b);
        System.out.println(a*b);
        System.out.println(a%b);
        System.out.println(a/b);
        System.out.println();
        System.out.println(10.0/3.0);
        System.out.println(10.0/3);
        System.out.println(10/3.0);
    }
}
