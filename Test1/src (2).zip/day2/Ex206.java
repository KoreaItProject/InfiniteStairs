package day2;

public class Ex206 {
    public static void main(String[] args) {
        System.out.println(3+3);
        System.out.println(3==3);
        System.out.println(3>4);
        System.out.println(3!=4);
        System.out.println(3!=3);

        int a=3,b=6,c=9;
        System.out.println(a+b==c);
        
    }
}
