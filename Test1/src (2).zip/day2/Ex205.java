package day2;

public class Ex205 {
    public static void main(String[] args) {
        int a=3;
        int b=5;
         b=a;
         System.out.println(b);//3
         a+=1;
         a/=2;
         a*=a;
         System.out.println(a);//4
         System.out.println(b);//3






    }
}
